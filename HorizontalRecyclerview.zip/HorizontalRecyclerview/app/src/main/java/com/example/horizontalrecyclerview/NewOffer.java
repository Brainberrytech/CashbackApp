package com.example.horizontalrecyclerview;

/**
 * @author Shayak Banerjee
 * @version 0.1
 * @since 12 June 2019
 */
class NewOffer {
    private String logoLink;
    private String companyName;
    private String numberOfRewards;

    /**
     * Constructor
     *
     * @param logoLink        URL of the logo
     * @param companyName     Name of the company offering the cashback
     * @param numberOfRewards number of rewards being offered by the company
     */
    NewOffer(String logoLink, String companyName, String numberOfRewards) {
        this.logoLink = logoLink;
        this.companyName = companyName;
        this.numberOfRewards = numberOfRewards;
    }

    String getLogoLink() {
        return logoLink;
    }


    String getCompanyName() {
        return companyName;
    }


    String getNumberOfRewards() {
        return numberOfRewards;
    }

}