package com.example.horizontalrecyclerview;

public class CarRecyclerViewItem {
    // Save car name.
    private String carName;

    // Save car image resource id.
    private int carImageId;

    CarRecyclerViewItem(String carName, int carImageId) {
        this.carName = carName;
        this.carImageId = carImageId;
    }

    String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    int getCarImageId() {
        return carImageId;
    }

    public void setCarImageId(int carImageId) {
        this.carImageId = carImageId;
    }
}
