package com.example.horizontalrecyclerview;


import android.os.Bundle;



public class H2_NavigationDrawer extends H2_NDBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setBaseContentView(R.layout.activity_h2__navigation_drawer);
    }
}
